# Review package · Forge d16f523 · 18 сентября 2026

Основной отчёт: `FORGE_REVIEW_d16f523_RU.md`.

Backlog: `FORGE_BACKLOG_d16f523.json` — 18 задач, 11 P1 и 7 P2. Priority — инженерный порядок, не CVSS. В репозитории issues не создавались.

`previous_findings_status.json` отделяет material fixes от partial closure и not independently retested. Не трактуйте наличие файла/теста как подтверждение сквозной гарантии.

## Локальные probes

`reproduce_review_findings.py` — семь **сокращённых behavioral probes**, не импорт полного Forge и не его pytest suite. Две проверки выполняют настоящие sync SQLAlchemy/SQLite operations; остальные фиксируют predicate/literal/scheduling semantics. Успешный exit означает воспроизведение наблюдений, а не исправность Forge.

```bash
python reproduce_review_findings.py --output reproduction_results.json
```

Требуется Python 3.10+ и SQLAlchemy 2.0.x. В review использованы Python3.13.5 и SQLAlchemy2.0.50; repository pin2.0.48. Внешние API не вызываются.

## Предлагаемые regression tests

`test_review_regressions.py` предназначен для окружения Forge. Он syntax-checked, **не исполнен здесь против Forge**. Это red tests на ожидаемый контракт, не patch реализации.

```bash
# Из корня Forge, с его зависимостями:
uv run pytest /path/to/review/test_review_regressions.py -q
```

`review_manifest.json` содержит SHA, ссылки на remote CI/release, какие jobs/steps наблюдались, ограничения проверки. `SHA256SUMS.txt` фиксирует состав этого комплекта.
