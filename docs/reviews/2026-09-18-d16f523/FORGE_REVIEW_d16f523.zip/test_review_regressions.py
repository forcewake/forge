"""Proposed red regression tests for Forge d16f523.

Run from a Forge checkout WITH its normal dependencies:
    uv run pytest /path/to/test_review_regressions.py -q
Or set FORGE_REPO_ROOT to the checkout directory.

These tests were syntax-checked, NOT executed against Forge in this review.
They intentionally assert the desired contract and should expose current defects.
No network calls, real credentials or provider writes are used.
"""
from __future__ import annotations

import os
from pathlib import Path

import pytest


def test_python_permission_entries_are_individual_rules() -> None:
    from forge.harness_entry import _CLAUDE_ALLOWED_TOOLS
    rules = {rule.strip() for rule in _CLAUDE_ALLOWED_TOOLS.split(',')}
    assert 'Bash(python3:*)' in rules
    assert 'Bash(python:*)' in rules
    assert 'Bash(.venv/bin/python:*)' in rules


def test_github_upload_root_is_non_hidden_or_explicitly_allowed() -> None:
    import yaml
    root = Path(os.environ.get('FORGE_REPO_ROOT', str(Path.cwd())))
    path = root / 'ci/templates/forge-harness.github.yml'
    assert path.exists(), 'Run in the Forge checkout or set FORGE_REPO_ROOT.'
    config = yaml.safe_load(path.read_text(encoding='utf-8'))
    uploads = [step for step in config['jobs']['harness']['steps']
               if str(step.get('uses','')).startswith('actions/upload-artifact@')]
    assert uploads, 'Expected a candidate-upload step.'
    for step in uploads:
        values = step.get('with',{})
        explicitly_allowed = str(values.get('include-hidden-files',False)).lower() == 'true'
        for raw in str(values.get('path','')).splitlines():
            name = Path(raw.strip().rstrip('/')).name
            assert not name.startswith('.') or explicitly_allowed, (
                f'Hidden artifact root {raw!r} without include-hidden-files=true'
            )


@pytest.mark.asyncio
@pytest.mark.parametrize('resolver_name',['resolve_status_target','resolve_retry_target'])
async def test_full_id_resolution_cannot_cross_project(resolver_name: str) -> None:
    from forge.durable.models import FlowRun
    from forge.runs import revival
    target = FlowRun(id='a'*32,provider='gitlab',project_id=202,issue_iid=7,
                     status='blocked',candidate_shas=['1'*40])

    class OneRowSession:
        async def get(self, model, identifier):
            assert model is FlowRun
            return target if identifier == target.id else None

    resolver = getattr(revival,resolver_name)
    result = await resolver(OneRowSession(),provider='gitlab',project_id=101,
                            issue_iid=7,requested=target.id,repo_full_name=None)
    assert result is None, 'The full-ID path must enforce the same project scope as prefix/bare IDs.'
