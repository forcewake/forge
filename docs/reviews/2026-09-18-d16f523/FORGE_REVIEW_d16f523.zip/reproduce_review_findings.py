#!/usr/bin/env python3
"""Reduced behavioral probes for forcewake/forge at d16f523.

These are NOT a local execution of the Forge test suite. The predicates and
operation ordering are transcribed from the reviewed sources; models, clocks,
transport and sessions are deliberately reduced. No external API is contacted.
The SQLAlchemy probes execute real synchronous SQLAlchemy/SQLite operations.
Exit 0 means every reported observation was reproduced, NOT that Forge is fixed.
"""
from __future__ import annotations

import argparse
import ast
import json
import platform
import tempfile
from dataclasses import asdict, dataclass
from pathlib import Path
from types import SimpleNamespace
from typing import Any
from sqlalchemy.orm import Mapped

SHA = 'd16f5233c641c490384438d9d0df6b4976b33d64'
BASE = f'https://github.com/forcewake/forge/blob/{SHA}/'

@dataclass
class Observation:
    id: str
    kind: str
    sources: list[str]
    result: dict[str, Any]
    limitations: str


def artifact_directory() -> Observation:
    # actions/toolkit internal-globber: excludeHiddenFiles && basename /^\./
    # actions/upload-artifact v4 search.ts passes excludeHiddenFiles=True by default.
    def skipped(search_root: str) -> bool:
        return Path(search_root).name.startswith('.')
    assert skipped('.forge-output') and not skipped('forge-output')
    return Observation('P01', 'transcribed_library_predicate',
        [BASE+'ci/templates/forge-harness.github.yml',
         'https://github.com/actions/upload-artifact/blob/v4/src/shared/search.ts',
         'https://github.com/actions/toolkit/blob/main/packages/glob/src/internal-globber.ts'],
        {'configured_root': '.forge-output', 'excluded_by_hidden_directory_predicate': True,
         'non_hidden_control_root': 'forge-output', 'control_excluded': False},
        'Does not execute the packaged GitHub Action or perform an artifact upload.')


def concatenated_allow_rules() -> Observation:
    # Exact adjacent-literal pattern from _CLAUDE_ALLOWED_TOOLS.
    fragment = ast.literal_eval('(' +
        '"Bash(python3:*)" "Bash(python:*)" '
        '"Bash(.venv/bin/python:*),Bash(./.venv/bin/python:*),"' + ')')
    rules = fragment.split(',')
    missing = [p for p in ['Bash(python3:*)','Bash(python:*)','Bash(.venv/bin/python:*)']
               if p not in rules]
    assert len(missing) == 3
    return Observation('P02', 'python_literal_evaluation', [BASE+'src/forge/harness_entry.py'],
        {'rendered_fragment': fragment, 'missing_individual_rules': missing},
        'Proves malformed list composition, not a live Claude CLI permission verdict.')


def verification_predicates() -> Observation:
    # Control flow after the nonempty-checks branch in evaluate_waiting_ci_one.
    def verdict(checks: list[dict[str, Any]]) -> str:
        pending = [c for c in checks if (c.get('status') or '') != 'completed']
        failed = [c for c in checks if (c.get('conclusion') or '') in
                  ('failure','timed_out','action_required','cancelled')]
        if pending:
            return 'waiting'
        if failed:
            return 'code_repair'
        return 'verified'
    rows = []
    for conclusion in ['success','skipped','neutral',None,'startup_failure','cancelled','timed_out']:
        checks = [{'name':'documentation', 'status':'completed', 'conclusion':conclusion}]
        rows.append({'conclusion':conclusion, 'current_verdict':verdict(checks)})
    assert verdict([{'status':'completed','conclusion':'skipped'}]) == 'verified'
    assert verdict([{'status':'completed','conclusion':'cancelled'}]) == 'code_repair'
    return Observation('P03', 'reduced_verifier_control_flow',
        [BASE+'src/forge/runs/github_service.py'],
        {'observations':rows,
         'required_jobs_are_not_inputs_to_this_inspected_decision':True,
         'harness_name_filter_example':{'configured':'forge-harness.github.yml',
             'api_display_name':'forge-harness', 'equal':False}},
        'No provider API or complete run lifecycle is executed. Required-job absence is also source-reviewed.')


def explicit_run_scope() -> Observation:
    # Full-id branch of resolve_retry_target/resolve_status_target.
    def existing_accepts(run: Any, *, provider: str, project_id: int,
                         issue_iid: int, repo_full_name: str | None = None) -> bool:
        if run is None or run.provider != provider or run.issue_iid != issue_iid:
            return False
        if repo_full_name is not None and run.github_repo_full_name != repo_full_name:
            return False
        return True
    other = SimpleNamespace(provider='gitlab', project_id=202, issue_iid=7,
                            github_repo_full_name=None)
    accepted = existing_accepts(other,provider='gitlab',project_id=101,issue_iid=7)
    assert accepted
    return Observation('P04','transcribed_resolution_predicate',
        [BASE+'src/forge/runs/revival.py', BASE+'src/forge/runs/service.py'],
        {'request_project_id':101,'returned_run_project_id':202,'same_issue_iid':7,
         'full_id_branch_accepts':accepted},
        'No actual unauthorized request is sent. Exploitation depends on ingress access, command authority and a known run ID.')


def stale_batch_claims() -> Observation:
    # Logical-time illustration of run_due_steps: claim batch now, execute sequentially.
    # Lease duration 120, heartbeat starts per executing step, not for the queued batch.
    leases = {1: {'owner':'A','expires':120}, 2:{'owner':'A','expires':120}}
    claims_a = [1,2]
    events = [{'t':0,'event':'A claims steps 1 and 2'}]
    leases[1]['expires'] = 240  # first step heartbeats while it runs until t=150
    now = 130
    assert leases[2]['expires'] < now
    leases[2] = {'owner':'B','expires':250}
    events.append({'t':130,'event':'reaper expires step 2; B claims and starts it'})
    now = 150
    # Existing for-loop starts previously claimed step 2 without a preflight claim validation.
    original_starts_second = claims_a[1] == 2
    stale = leases[2]['owner'] != 'A'
    assert original_starts_second and stale
    events.append({'t':150,'event':'A reaches step 2 using its old claim; first heartbeat is later'})
    return Observation('P05','deterministic_scheduler_model',
        [BASE+'src/forge/worker/steps.py'],
        {'events':events,'stale_claim_entered_handler':True},
        'A schedule model, not a reproduction with the production workers/Postgres. It establishes the reachable ordering to test.')


def sqlalchemy_probes() -> list[Observation]:
    import sqlalchemy as sa
    from sqlalchemy import String, create_engine, select
    from sqlalchemy.exc import IntegrityError, PendingRollbackError
    from sqlalchemy.orm import DeclarativeBase, Mapped, Session, mapped_column

    class BaseModel(DeclarativeBase):
        pass
    class BudgetRow(BaseModel):
        __tablename__='probe_budget'
        id: Mapped[int] = mapped_column(primary_key=True)
        run_id: Mapped[str] = mapped_column(String, unique=True)
    class RunRow(BaseModel):
        __tablename__='probe_run'
        id: Mapped[int] = mapped_column(primary_key=True)
        status: Mapped[str] = mapped_column(String)

    with tempfile.TemporaryDirectory(prefix='forge-review-') as temp:
        engine = create_engine('sqlite:///'+str(Path(temp)/'probe.db'))
        BaseModel.metadata.create_all(engine)
        with Session(engine) as winner:
            winner.add(BudgetRow(run_id='same-run'))
            winner.add(RunRow(id=1,status='reviewing'))
            winner.commit()
        # The preceding SELECT raced with a winning opener. Reduce to the same
        # pending duplicate INSERT present before begin_nested() is invoked.
        with Session(engine) as loser:
            loser.add(BudgetRow(run_id='same-run'))
            try:
                with loser.begin_nested():
                    loser.flush()
            except IntegrityError:
                try:
                    loser.scalar(select(BudgetRow).where(BudgetRow.run_id=='same-run'))
                except PendingRollbackError:
                    poisoned = True
                else:
                    poisoned = False
            else:
                raise AssertionError('duplicate insert unexpectedly succeeded')
            loser.rollback()
        assert poisoned
        with Session(engine) as fixed:
            try:
                with fixed.begin_nested():
                    fixed.add(BudgetRow(run_id='same-run'))
                    fixed.flush()
            except IntegrityError:
                adopted = fixed.scalar(select(BudgetRow).where(BudgetRow.run_id=='same-run'))
                fixed_can_read = adopted is not None
        assert fixed_can_read

        # Same read/check/ORM-write pattern as unguarded Controller.transition.
        with Session(engine, expire_on_commit=False) as s1, Session(engine, expire_on_commit=False) as s2:
            r1 = s1.get(RunRow,1)
            r2 = s2.get(RunRow,1)
            assert r1 is not None and r2 is not None
            r1.status='cancelled'; s1.commit()
            stale_observation = r2.status
            assert stale_observation=='reviewing'
            # A legality check on this old object admits reviewing -> ready_for_human.
            r2.status='ready_for_human'; s2.commit()
        with Session(engine) as verify:
            actual = verify.get(RunRow,1)
            final_status = actual.status if actual else None
        assert final_status=='ready_for_human'
        engine.dispose()
    return [
        Observation('P06','real_sqlalchemy_reduced_transaction',
            [BASE+'src/forge/durable/budgets.py'],
            {'sqlalchemy_version':sa.__version__, 'bad_order_exception':'PendingRollbackError',
             'add_inside_savepoint_control_can_read_winner':fixed_can_read},
            'Sync SQLAlchemy '+sa.__version__+' on SQLite; Forge pins 2.0.48 with AsyncSession/Postgres. Shared pre-SAVEPOINT flush semantics are corroborated by official docs.'),
        Observation('P07','real_sqlalchemy_reduced_concurrency',
            [BASE+'src/forge/durable/controller.py'],
            {'sqlalchemy_version':sa.__version__, 'second_session_observation':stale_observation,
             'first_session_committed':'cancelled','final_status':final_status},
            'Two real sessions in a controlled sequential interleaving; no complete Forge service/reconciler or production database was run.'),
    ]


def main() -> None:
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path)
    args=parser.parse_args()
    observations=[artifact_directory(),concatenated_allow_rules(),verification_predicates(),
                  explicit_run_scope(),stale_batch_claims(),*sqlalchemy_probes()]
    document={'reviewed_sha':SHA,'python':platform.python_version(),
        'scope':'isolated reduced probes, NOT the Forge test suite',
        'observations_reproduced':len(observations),
        'observations':[asdict(x) for x in observations]}
    text=json.dumps(document,ensure_ascii=False,indent=2)
    if args.output:
        args.output.parent.mkdir(parents=True,exist_ok=True)
        args.output.write_text(text+'\n',encoding='utf-8')
    print(text)

if __name__=='__main__':
    main()
